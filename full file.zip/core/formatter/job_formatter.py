
class JobFormatter:
    def format(self, df):
        keep=["title","company","location","description","redirect_url"]
        return df[keep].copy()
