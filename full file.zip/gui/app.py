
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from gui.theme import apply_dark_theme
from gui.results_popup import ResultsPopup
from core.utils.file_loader import load_text_from_file
from core.fetcher.adzuna_fetcher import AdzunaFetcher
from core.cleaner.resume_cleaner import ResumeCleaner
from core.embedder.openai_embedder import OpenAIEmbedder
from core.scrubber.scrubber import Scrubber
from core.formatter.job_formatter import JobFormatter
from core.pipeline.pipeline import Pipeline

def trim_path(path):
    p=path.replace('\\','/').split('/')
    if len(path)<40: return path
    return p[0] + "/.../" + p[-1]

class App:
    def __init__(self):
        self.root=tk.Tk()
        self.root.title("Adzuna SOLID Pipeline v3")
        apply_dark_theme(self.root)

        main=ttk.Frame(self.root)
        main.pack(fill="both", expand=True, padx=10, pady=10)

        left=ttk.Frame(main)
        right=ttk.Frame(main)

        left.pack(side="left", fill="y")
        right.pack(side="right", fill="both", expand=True)

        self.resume_path=None

        ttk.Button(left, text="Upload Resume", command=self.load_resume).pack(pady=10)
        self.resume_label=ttk.Label(left, text="No resume loaded")
        self.resume_label.pack(pady=10)

        ttk.Button(left, text="Run Pipeline", command=self.run_pipeline).pack(pady=10)

        self.logbox=tk.Text(right, height=25, bg="#1e1e1e", fg="white")
        self.logbox.pack(fill="both", expand=True)

    def log(self,msg):
        self.logbox.insert("end", msg+"\n")
        self.logbox.see("end")
        self.root.update()

    def load_resume(self):
        path=filedialog.askopenfilename(filetypes=[("Docs","*.pdf *.txt *.docx")])
        if path:
            self.resume_path=path
            self.resume_label.config(text="Resume Loaded:\n"+trim_path(path))
            self.log(f"[Resume] Loaded {path}")

    def run_pipeline(self):
        if not self.resume_path:
            messagebox.showerror("Error","Upload a resume first.")
            return

        app_id=simpledialog.askstring("Adzuna App ID","Enter App ID:",parent=self.root)
        app_key=simpledialog.askstring("Adzuna App Key","Enter App Key:",parent=self.root)
        if not app_id or not app_key:
            messagebox.showerror("Error","Missing Adzuna credentials.")
            return

        self.log("[0] Loading resume text...")
        resume_text=load_text_from_file(self.resume_path)

        fetcher=AdzunaFetcher(app_id, app_key, self.log)
        cleaner=ResumeCleaner()
        embedder=OpenAIEmbedder(self.log)
        scrubber=Scrubber()
        formatter=JobFormatter()
        pipeline=Pipeline(fetcher,cleaner,embedder,scrubber,formatter,self.log)

        df=pipeline.run(resume_text, "software engineer", "St. Louis", 25)
        self.log("[9] Showing results popup...")
        ResultsPopup(self.root, df)

    def run(self):
        self.root.mainloop()
